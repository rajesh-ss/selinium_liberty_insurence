package com.selenium.libertyA;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class savingsAndMorePage {

	WebDriver driver;
	By getTheQuote_id = By.id("nextButton-0");
	By checkSprinklerSystem_xpath = By.xpath("//*[@id=\"hasSprinklerSystem-insuredLocation-0\"]/label");
	
	public savingsAndMorePage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void enterAllDetailsCorrect() {
		checkSprinklerSystem();
		getTheQuote();
	}
	
	public void getTheQuote() {
		driver.findElement(getTheQuote_id).click();
	}
	
	public void checkSprinklerSystem() {
		driver.findElement(checkSprinklerSystem_xpath).click();
	}
	
	
}
