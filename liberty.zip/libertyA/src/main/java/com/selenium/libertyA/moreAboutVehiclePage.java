package com.selenium.libertyA;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

/*
 * 
 * personalUse_id
 * businessUse_id
 *  
 */

public class moreAboutVehiclePage {

	WebDriver driver;
	By purchaseYear_id = By.id("purchaseDate-vehicle-0_selectNode");
	By personalUse_xpath = By.xpath("//*[@id=\"primaryUse-vehicle-0\"]/div[2]/div/div[1]/label");
	By businessUse_id = By.id("primaryUse-vehicle-0-03");
	By businessUse_xpath = By.xpath("//*[@id=\"primaryUse-vehicle-0\"]/div[2]/div/div[2]");
	By newVehiclePurchased_id = By.id("purchasedNew-vehicle-0-01");
	By newVehiclePurchased_xpath = By.xpath("//*[@id=\"purchasedNew-vehicle-0\"]/div[2]/div/div[1]");
	By oldVehiclePurchased_id = By.id("purchasedNew-vehicle-0-02");
	By oldVehiclePurchased_xpath = By.xpath("//*[@id=\"purchasedNew-vehicle-0\"]/div[2]/div/div[2]");
	By ownedVihicle_id = By.id("ownership-vehicle-0-01");
	By ownedVihicle_xpath = By.xpath("//*[@id=\"ownership-vehicle-0\"]/div[2]/div/div[1]/label");
	By financedVihicle_id = By.id("ownership-vehicle-0-03");
	By financedVihicle_xpath = By.xpath("//*[@id=\"ownership-vehicle-0\"]/div[2]/div/div[2]/label");
	By leasedVihicle_id = By.id("ownership-vehicle-0-02");
	By leasedVihicle_xpath = By.xpath("//*[@id=\"ownership-vehicle-0\"]/div[2]/div/div[3]");
	By vihicleKeptAtAddressYes_xpath = By.xpath("//*[@id=\"keptAtResidence-vehicle-0\"]/div[2]/div/div[1]");
	By vihicleKeptAtAddressNo_xpath = By.xpath("//*[@id=\"keptAtResidence-vehicle-0\"]/div[2]/div/div[2]");
	By mileage_xpath = By.xpath("//*[@id=\"annualDistance-vehicle-0\"]/span[2]/input");
	By moreVehicleToNextPage_id = By.id("nextButton-1");
	
	public moreAboutVehiclePage(WebDriver driver) {
		this.driver = driver;
	}

	public void enterAllDetailsCorrect() throws IOException {

		// driver.findElement(By.id(prop.getProperty(""))).click();
		// obb.getTheData("year_purchased", "moreVehicleInfo")
		//

		getExcelData obb = new getExcelData();
		selectYearOfPurchase(obb.getTheData("year_purchased", "moreVehicleInfo"));
		purchasedAsNew();
		selectOwned();
		selectOwned();
		String primaryUserOfVehicle = primaryUserOfVehicleExcelData();

		if (primaryUserOfVehicle.equals("Personal")) {
			usagePersonal();
		} else if (primaryUserOfVehicle.equals("Business")) {
			usageBusiness();
		}

		// purchasedAsNew(); annual_mileage

		giveEstimatedMileage(obb.getTheData("annual_mileage", "moreVehicleInfo"));
		keptAtAddressYes();
		goToNextPage();
	}

	public void goToNextPage() {
		driver.findElement(moreVehicleToNextPage_id).click();
	}
	
	
	public void keptAtAddressYes() {
		driver.findElement(vihicleKeptAtAddressYes_xpath).click();
	}

	public void giveEstimatedMileage(String mileage) {
		// int mm = Integer.parseInt(mileage);
		System.out.println(mileage);
		driver.findElement(mileage_xpath).clear();
		driver.findElement(mileage_xpath).sendKeys(mileage);
	}

	public void selectOwned() {
		// ownedVihicle_id
		 //driver.findElement(By.xpath("//*[@id=\"ownership-vehicle-0\"]/div[2]/div/div[1]/label")).click();
		driver.findElement(ownedVihicle_xpath).click();
	}

	public void selectFinanced() {
		// financedVihicle_id
		driver.findElement(financedVihicle_xpath).click();
	}

	public void selectLeased() {
		// leasedVihicle_id
		driver.findElement(leasedVihicle_xpath).click();
	}

	public void usagePersonal() {
		driver.findElement(personalUse_xpath).click();
	}

	public void usageBusiness() {
		driver.findElement(businessUse_xpath).click();
	}

	public void selectYearOfPurchase(String yearOfPurchase) {

		Select year = new Select(driver.findElement(purchaseYear_id));
		year.selectByVisibleText(yearOfPurchase);
	}

	public void purchasedAsNew() {
		driver.findElement(newVehiclePurchased_xpath).click();
	}

	public void purchasedAsOld() {
		// oldVehiclePurchased_id
		driver.findElement(oldVehiclePurchased_xpath).click();
	}

	public String primaryUserOfVehicleExcelData() throws IOException {

		
		// * Select(driver.findElement(By.id(prop.getProperty("purchaseYear_id"))));
		// * year.selectByValue(obb.getTheData("year_purchased", "moreVehicleInfo"));

		String tmp = "";
		getExcelData obb = new getExcelData();
		if (obb.getTheData("vehicle_use", "moreVehicleInfo").equals("Personal")) {
			tmp = "Personal";
			return tmp;

		} else if (obb.getTheData("vehicle_use", "moreVehicleInfo").equals("Business")) {

			tmp = "Business";
			return tmp;
		}

		return tmp;

	}

}
