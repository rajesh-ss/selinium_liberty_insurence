package com.selenium.libertyA;

import java.util.Properties;

import org.openqa.selenium.WebDriver;

public class finalVehicleInfo {

	WebDriver driver;
	Properties prop;
	
	public finalVehicleInfo(WebDriver driver, Properties prop) {
		this.driver = driver;
		this.prop = prop;
	}
	
	
}
