package com.selenium.libertyA;


import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class addressPage {

	By address_xpath = By.xpath("//*[@name='address']");
	By apt_xpath = By.xpath("//*[@id=\"additionalStreetAddress-customer-0\"]/span[2]/input");
	By yes_id = By.id("priorResidenceAddressIndicator-customer-0-Y");
	By saveContinue_id = By.id("nextButton-0");
	
	public WebDriver driver;
	
	
	
	public addressPage(WebDriver driver) {
		this.driver = driver;		
	}
	
	public String getStreetAddrExcel(getExcelData obb ) throws IOException {
		return obb.getTheData("street_addr","personalData");
	}
	
	public String aptUnitExcel(getExcelData obb ) throws IOException {
		return obb.getTheData("apt/unit","personalData");
	}
	
	public void enterStreetAddr(String streetAddr) {
		driver.findElement(address_xpath).sendKeys(streetAddr);
	}
	
	public void enterAptUnit(String AptUnit) {
		driver.findElement(apt_xpath).sendKeys(AptUnit);
	}
	
	public void goToNxtPage() {
		driver.findElement(saveContinue_id).click();
	}
	
	public void enterAllDetailsCorrect() throws IOException {
		
		String streetAddr=  "";
		String AptUnit =  ""; 
		getExcelData obb = new getExcelData();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
		enterStreetAddr(getStreetAddrExcel(obb));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
		enterAptUnit(aptUnitExcel(obb));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
		//driver.findElement(By.id(prop.getProperty("yes_id"))).click();
		goToNxtPage();
	}
	
	
	

}
