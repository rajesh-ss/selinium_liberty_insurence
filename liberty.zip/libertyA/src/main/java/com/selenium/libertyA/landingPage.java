package com.selenium.libertyA;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class landingPage {
	
	By bundle_xpath = By.xpath("//button[@value='Bundle']");
	By autoCondo_xpath = By.xpath("//*[@value='bundle-auto_condo']");
	By zipInput_xpath = By.xpath("//input[@id='alphaNumericInput1-input']");
	By getPrice_class = By.className("lm-Button lm-Button--large lm-Button--primary jsx-2489552829");
	String CA_zipcode = "90224";
	
	public WebDriver driver = null;

	public landingPage(WebDriver driver) {
		this.driver= driver;
	}
	
	public void AutoCondo() {
		driver.findElement(bundle_xpath).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		driver.findElement(autoCondo_xpath).click();
		//driver.findElement(By.xpath(prop.getProperty("autoCondo_xpath"))).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		driver.findElement(zipInput_xpath).sendKeys(CA_zipcode);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		driver.findElement(zipInput_xpath).sendKeys(Keys.ENTER);
		//driver.findElement(By.className(prop.getProperty("getPrice_class"))).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
	}
	


}
