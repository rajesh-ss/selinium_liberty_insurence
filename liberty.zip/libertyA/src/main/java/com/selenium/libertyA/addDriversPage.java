package com.selenium.libertyA;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class addDriversPage {

	WebDriver driver;

	/*******************************************************************************************
	 ********************************* The Locators ********************************************
	 *******************************************************************************************/

	By yesMarried_xpath = By.xpath("//*[@id=\"maritalStatus-driver-0\"]/div[2]/div/div[1]/label");
	By noMarried_xpath = By.xpath("//*[@id=\"maritalStatus-driver-0\"]/div[2]/div/div[2]/label");
	By addDriversTonxtPage_id = By.id("nextButton-0");

	public addDriversPage(WebDriver driver) {
		this.driver = driver;
	}

	/*******************************************************************************************
	 ********************************* yes to married *******************************************
	 *******************************************************************************************/

	public void clickYesMarried() {
		driver.findElement(yesMarried_xpath).click();
	}

	/*******************************************************************************************
	 ********************************* no to married *******************************************
	 *******************************************************************************************/

	public void clickNoMarries() {
		driver.findElement(noMarried_xpath).click();
	}

	/*******************************************************************************************
	 ********************************* Next Page ***********************************************
	 *******************************************************************************************/

	public void goToNxtPage() {
		driver.findElement(addDriversTonxtPage_id).click();
	}

	/*******************************************************************************************
	 ************************ Test-1 All details are correct ***********************************
	 *******************************************************************************************/

	public void enterAllDetailsCorrect() {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		clickNoMarries();
		goToNxtPage();
	}

}
