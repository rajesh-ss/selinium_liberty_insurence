package com.selenium.libertyA;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class addSecondaryCondoPage {

	WebDriver driver;
	By noSecondaryCondo_xpath = By.xpath("//*[@id=\"coapplicantIndicator-insured-0\"]/div[2]/div/div[2]/label");
	By yesSecondaryCondo_xpath = By.xpath("//*[@id=\"coapplicantIndicator-insured-0\"]/div[2]/div/div[1]/label");
	By addSecondaryCondoToNxtPage_id = By.id("nextButton-1");
	
	
	
	public addSecondaryCondoPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void correctDetails() {
		noSecondaryCondo();
		goToNxtPage();
	}
	
	public void noSecondaryCondo() {
		driver.findElement(noSecondaryCondo_xpath).click();
	}
	
	public void yesSecondaryCondo() {
		driver.findElement(yesSecondaryCondo_xpath).click();
	}
	
	public void goToNxtPage() {
		driver.findElement(addSecondaryCondoToNxtPage_id).click();
	}
	
}
