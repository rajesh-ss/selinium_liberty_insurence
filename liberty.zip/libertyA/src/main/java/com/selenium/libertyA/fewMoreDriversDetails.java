package com.selenium.libertyA;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class fewMoreDriversDetails {

	WebDriver driver;
	By ph_xpath = By.xpath("//*[@id=\"phoneNumber-customer-0\"]/span[2]/div/div/input");
	By licensedAge_xpath = By.xpath("//*[@id=\"ageLicensed-driver-0\"]/span[2]/input");
	By noLicenseOutside_xpath = By.xpath("//*[@id=\"hasHeldInternationalLicenseIndicator-driver-0\"]/div[2]/div/div[2]/label");
	By highSchool_xpath = By.xpath("//*[@id=\"highestEducationLevel-driver-0\"]/div[2]/div/div[1]/label");
	By vocational_xpath = By.xpath("//*[@id=\"highestEducationLevel-driver-0\"]/div[2]/div/div[2]/label");
	By bachelors_xpath = By.xpath("//*[@id=\"highestEducationLevel-driver-0\"]/div[2]/div/div[3]/label");
	By advanced_xpath = By.xpath("//*[@id=\"highestEducationLevel-driver-0\"]/div[2]/div/div[4]/label");
	By emplymentStatus_id = By.id("employmentStatus-driver-0_selectNode");
	By NoViolation_xpath = By.xpath("//*[@id=\"hasIncidents-driver-0\"]/div[2]/div/div[2]/label");
	By driverDetailsNxtPage_id = By.id("nextButton-1");
	
	
	public fewMoreDriversDetails(WebDriver driver) {
		this.driver = driver;
	}
	
	public void enterAllDetailsCorrect() throws IOException {
		getExcelData obb = new getExcelData();
		givePH(obb.getTheData("ph", "driverDetails"));
		LicensedAge(obb.getTheData("ageLicensed", "driverDetails"));
		ClickNoOutsideUSA();
		ClickHighSchool();
		selectEmploymentStatus(obb.getTheData("employmentStatus", "driverDetails"));
		noClaimsViolations();
		goNxtPage();
		
	}
	
	public void givePH(String ph) {
		driver.findElement(ph_xpath).clear();
		driver.findElement(ph_xpath).sendKeys(ph);
	}
	
	public void LicensedAge(String age) {
		driver.findElement(licensedAge_xpath).clear();
		driver.findElement(licensedAge_xpath).sendKeys(age);
	}
	
	public void ClickNoOutsideUSA() {
		driver.findElement(noLicenseOutside_xpath).click();
	}
	
	public void ClickHighSchool() {
		driver.findElement(highSchool_xpath).click();
	}
	
	public void ClickVocational() {
		driver.findElement(vocational_xpath).click();
	}
	
	public void ClickBachelors() {
		driver.findElement(bachelors_xpath).click();
	}
	
	public void AdvancedDegree() {
		driver.findElement(advanced_xpath).click();
	}
	
	public void selectEmploymentStatus(String status) {
		Select sc = new Select(driver.findElement(emplymentStatus_id));
		sc.selectByVisibleText(status);	
	}
	
	public void noClaimsViolations() {
		driver.findElement(NoViolation_xpath).click();
	}
	
	public void goNxtPage() {
	driver.findElement(driverDetailsNxtPage_id).click();
	}
}
