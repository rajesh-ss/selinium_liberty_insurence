package com.selenium.libertyA;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class getExcelData {

	public String getTheData(String data, String sheetName) throws IOException {
		
		String tmp = null;
		Workbook wb = null;
		try {
			String userid = System.getProperty("user.dir");
			FileInputStream fis = new FileInputStream(new File(userid + "/Book1.xlsx"));
			wb = new XSSFWorkbook(fis);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		for (int i = 0; i > -1; i++) {
			Sheet sheet = wb.getSheet(sheetName);
			Row row = sheet.getRow(i);
			Cell cell = row.getCell(0);
			if (cell == null) {
				break;
			} else {
				if (ReadCellData(i, 0, sheetName).equals(data)) {
					tmp = ReadCellData(i, 1, sheetName);
					System.out.println(tmp);
					return tmp;
				}
			}
		}
		return tmp;
	}

	public String ReadCellData(int vRow, int vColumn, String sheetName) {

		String value = null;
		Workbook wb = null;
		try {
			String userid = System.getProperty("user.dir");
			FileInputStream fis = new FileInputStream(new File(userid + "/Book1.xlsx"));
			wb = new XSSFWorkbook(fis);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		Sheet sheet = wb.getSheet(sheetName);
		Row row = sheet.getRow(vRow);
		Cell cell = row.getCell(vColumn);
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_STRING:
			value = cell.getStringCellValue();
			break;
		case Cell.CELL_TYPE_NUMERIC:
			double tmp = cell.getNumericCellValue();
			int tmpInt = (int) (tmp);
			value = Integer.toString(tmpInt);
			break;
		default:
		}
		return value;

	}
}
