package com.selenium.libertyA;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class personalDataPage {
	
	WebDriver driver;
	By  firstName_name  = By.name("firstName");
	By lastName_name  = By.name("lastName");
	By month_xpath = By.xpath("//*[@class='sm_cobrowsing_hidden_field sm_cobrowsing_disabled_field']");
	By day_xpath = By.xpath("//*[@name='day']");
	By year_xpath = By.xpath("//*[@name='year']");
	By email_xpath = By.xpath("//*[@name='email']");
	By next_id = By.id("nextButton-1");
	
	
	public personalDataPage(WebDriver driver) {
		this.driver = driver;
	}
 
	public String getfirst_nameExcel(getExcelData obb) throws IOException {
		return obb.getTheData("first_name","personalData");
	}
	public String getlast_nameExcel(getExcelData obb) throws IOException {
		return obb.getTheData("last_name","personalData");
	}
	public String getemailExcel(getExcelData obb) throws IOException {
		return obb.getTheData("email","personalData");
	}
	
	public String[] getDOB(getExcelData obb) throws IOException {
		String dob = obb.getTheData("dob","personalData");
		return dobSeparate(dob);
	}
	
	public String getDayExcel(getExcelData obb) throws IOException {
		String[] dob = getDOB(obb);
		return dob[1];
	}
	
	public String getMonExcel(getExcelData obb) throws IOException {
		String[] dob = getDOB(obb);
		return dob[0];
	}
	
	public String getYearExcel(getExcelData obb) throws IOException {
		String[] dob = getDOB(obb);
		return dob[2];
	}
	
	public void enterFirstName(String first_name) {
		driver.findElement(firstName_name).sendKeys(first_name);
	}
	
	public void enterLastName(String last_name) {
		driver.findElement(lastName_name).sendKeys(last_name);
	}
	
	public void slectMonth(String mon) {
		Select month = new Select(driver.findElement(month_xpath));
		month.selectByValue(mon);
	}
	
	public void enterDay(String day) {
		driver.findElement(day_xpath).sendKeys(day);
	}
	public void enterYear(String year) {
		driver.findElement(year_xpath).sendKeys(year);
	}
	
	public void enterEmail(String email) {
		driver.findElement(email_xpath).sendKeys(email);
	}
	
	public void goToNxtPage() {
		driver.findElement(next_id).click();
	}
	
	public void enterAllDetailsCorrect() throws IOException {
		
		getExcelData obb = new getExcelData();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		enterFirstName(getfirst_nameExcel(obb));		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		enterLastName(getlast_nameExcel(obb));	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		slectMonth(getDayExcel(obb));
		enterDay(getMonExcel(obb));
		enterYear(getYearExcel(obb));
		enterEmail(getemailExcel(obb));
		goToNxtPage();
	}

	public String[] dobSeparate(String dob) {
		String[] arrDate = dob.split("-");
		return arrDate;
	}

}
