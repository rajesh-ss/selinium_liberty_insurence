package com.selenium.libertyA;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class vehicleInfoPage {

	WebDriver driver;
	By selectYear_id = By.id("year-vehicle-0_selectNode");
	By selectMake_id = By.id("make-vehicle-0_selectNode");
	By selectModel_id = By.id("model-vehicle-0_selectNode");
	By selectTrim_id = By.id("fullModelName-vehicle-0_selectNode");
	By selectBodyStyle_id = By.id("bodyStyle-vehicle-0_selectNode");
	By vechicleToNextPage_id = By.id("nextButton-0");
	
	
	public vehicleInfoPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void selectYear(String year) {
		Select scYear = new Select(driver.findElement(selectYear_id));
		scYear.selectByValue(year);
	}
	
	public String getYearExcel(getExcelData obb) throws IOException {
		return obb.getTheData("year", "vehicleInfo");
	}
	
	public void selectMake(String make) {
		Select scMake = new Select(driver.findElement(selectMake_id));
		scMake.selectByValue(make);
	}
	
	public String getMakeExcel(getExcelData obb) throws IOException {
		return obb.getTheData("make", "vehicleInfo");
	}
	
	public void selectModel(String model) {
		Select scModel = new Select(driver.findElement(selectModel_id));
		scModel.selectByValue(model);
	}
	
	public String getModelExcel(getExcelData obb)throws Exception{
		return obb.getTheData("model", "vehicleInfo");
	}
	
	public void selectTrim(String trim) {
		Select scTrim = new Select(driver.findElement(selectTrim_id));
		scTrim.selectByValue(trim);
	}
	
	public String getTrimExcel(getExcelData obb) throws IOException {
		return obb.getTheData("trim", "vehicleInfo");	
	}
	
	public void selectBodyStyle(String trim) {
		Select body_style = new Select(driver.findElement(selectBodyStyle_id));
		body_style.selectByValue(trim);
	}
	
	public String getBodyStyle(getExcelData obb) throws IOException{
		return obb.getTheData("body style", "vehicleInfo");
	}
	
	public void getToNxtPage() {
		driver.findElement(vechicleToNextPage_id).click();
	}
	
	public void enterAllDetailsCorrect() throws Exception {
		
		
		getExcelData obb = new getExcelData();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
		selectYear(getYearExcel(obb));
		selectMake(getMakeExcel(obb));	
		selectModel(getModelExcel(obb));
		selectTrim(getTrimExcel(obb));		
		selectBodyStyle(getBodyStyle(obb));		
		getToNxtPage();	
		
	}
}
