package com.selenium.libertyA;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class currentInsuranceDetailsPage {

	WebDriver driver;
	By selectCurrentInsuranc_id = By.id("propertyCurrentlyInsuredCode-insuranceHistory-0_selectNode");
	By yesPaymentCancelled_xpath = By.xpath("//*[@id=\"policyCancellationIndicator-insuranceHistory-0\"]/div[2]/div/div[1]/label");
	By noPaymentCancelled_xpath = By.xpath("//*[@id=\"policyCancellationIndicator-insuranceHistory-0\"]/div[2]/div/div[2]/label");
	By yesFamilyMemberLiberty_xpath = By.xpath("//*[@id=\"hasLifePolicyWithLiberty-insuranceHistory-0\"]/div[2]/div/div[1]/label");
	By noFamilyMemberLiberty_xpath = By.xpath("//*[@id=\"hasLifePolicyWithLiberty-insuranceHistory-0\"]/div[2]/div/div[2]/label");
	By yesHadInsuranceClaimed_xpath = By.xpath("//*[@id=\"claimLossIndicator-insuranceHistory-0\"]/div[2]/div/div[1]/label");
	By noHadInsuranceClaimed_xpath = By.xpath("//*[@id=\"claimLossIndicator-insuranceHistory-0\"]/div[2]/div/div[2]/label");
	By CurrentInsuranceToNxtPage_id = By.id("nextButton-0");
	
	public currentInsuranceDetailsPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void fillCurrentDetails() {
		SelectnoInsuranceCurrentAddress();
		noPolicyGotCancelledPayment();
		noFamilyMemberLiberty();
		noHadInsuranceClaimed();
		goToNxtPage();
		
	}
	
	public void SelectnoInsuranceCurrentAddress() {
		Select sc = new Select(driver.findElement(selectCurrentInsuranc_id));
		sc.selectByVisibleText("No");
	}
	
	public void SelectOtherInsuranceCurrentAddress() {
		Select sc = new Select(driver.findElement(selectCurrentInsuranc_id));
		sc.selectByVisibleText("Yes, with another insurance company");
	}
	
	public void SelectLibertyInsuranceCurrentAddress() {
		Select sc = new Select(driver.findElement(selectCurrentInsuranc_id));
		sc.selectByVisibleText("Yes, with Liberty Mutual");
	}
	
	public void yesPolicyCancelledPayment() {
		driver.findElement(yesPaymentCancelled_xpath).click();
	}
	
	public void noPolicyGotCancelledPayment() {
		driver.findElement(noPaymentCancelled_xpath).click();
	}
	
	public void yesFamilyMemberLiberty() {
		driver.findElement(yesFamilyMemberLiberty_xpath).click();
	}
	
	public void noFamilyMemberLiberty() {
		driver.findElement(noFamilyMemberLiberty_xpath).click();
	}
	
	public void yesHadInsuranceClaimed() {
		driver.findElement(yesHadInsuranceClaimed_xpath).click();
	}
	
	public void noHadInsuranceClaimed() {
		driver.findElement(noHadInsuranceClaimed_xpath).click();
	}
	
	public void goToNxtPage() {
		driver.findElement(CurrentInsuranceToNxtPage_id).click();
	}
	
}
