package com.selenium.libertyA;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class adressWantToInsurancePage {

	WebDriver driver;
	By yourInfoToNxtPage_id = By.id("nextButton-0");
	
	public adressWantToInsurancePage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void noAdressChangeNxtPage() {
		driver.findElement(yourInfoToNxtPage_id).click();
	}
}
