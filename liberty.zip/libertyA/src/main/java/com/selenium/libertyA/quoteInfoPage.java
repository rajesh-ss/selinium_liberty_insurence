package com.selenium.libertyA;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class quoteInfoPage {

	WebDriver driver;
	By closePopUp_xpath = By.xpath("//*[@id=\"info-dialog\"]/a");
	By finiliseMyPrice_xpath = By.xpath("//*[@id=\"widget-3\"]/div/div[2]/button");
	By closeAndContinue_xpath = By.xpath("//*[@id=\"info-dialog\"]/div[2]/div[2]/a");
	
	
	public quoteInfoPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void closePopUp() {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(closePopUp_xpath).click();
	}
	
	public void finiliseMyPrice() {
		driver.findElement(finiliseMyPrice_xpath).click();
	}
	
}
