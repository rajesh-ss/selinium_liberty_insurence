package com.selenium.libertyA;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class funDiscountPage {

	WebDriver driver;
	By funDiscountToNxtPage_id = By.id("nextButton-0");
	
	
	public funDiscountPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void goToNxtPage() {
		driver.findElement(funDiscountToNxtPage_id).click();
	}
	
}
