package com.selenium.libertyA;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class propertyInfoPage {
	
	WebDriver driver;
	By selectPurchasedMonth_xpath = By.xpath("//*[@id=\"propertyPurchaseDate-insuredLocation-0\"]/div/label[1]/select");
	By selectPurchasedYear_xpath = By.xpath("//*[@id=\"propertyPurchaseDate-insuredLocation-0\"]/div/label[2]/select");
	By yearBuilt_xpath = By.xpath("//*[@id=\"yearBuilt-insuredLocation-0\"]/span[2]/input");
	By selectNoOfUnits_id = By.id("unitsInBuilding-insuredLocation-0_selectNode");
	By slectHomeDescribe_id = By.id("homeOccupancy-insuredLocation-0_selectNode");
	By minimun15k_xpath = By.xpath("//*[@id=\"replacementCost-insuredLocation-0\"]/div[2]/div/div[1]/label");
	By average25k_xpath = By.xpath("//*[@id=\"replacementCost-insuredLocation-0\"]/div[2]/div/div[2]/label");
	By thirteenK_xpath = By.xpath("//*[@id=\"replacementCost-insuredLocation-0\"]/div[2]/div/div[3]/label");
	By otherAmount_xpath = By.xpath("//*[@id=\"replacementCost-insuredLocation-0\"]/div[2]/div/div[4]/label");
	By yesDogs_xpath = By.xpath("//*[@id=\"dogIndicator-insuredLocation-0\"]/div[2]/div/div[1]/label");
	By noDogs_xpath = By.xpath("//*[@id=\"dogIndicator-insuredLocation-0\"]/div[2]/div/div[2]/label");
	By exteriorWall_id = By.id("outsideWallMaterial-insuredLocation-0_selectNode");
	By propertyInfoToNxtPage_id = By.id("nextButton-1");
	
	
	
	public propertyInfoPage(WebDriver driver) {
		this.driver = driver;
	}

	public void purchaseMonth(String month) {
		Select sc = new Select(driver.findElement(selectPurchasedMonth_xpath));
		sc.selectByVisibleText(month);
	}
	
	public void purchaseYear(String year) {
		Select sc = new Select(driver.findElement(selectPurchasedYear_xpath));
		sc.selectByVisibleText(year);
	}
	
	public void fillYearBuild(String year) {
		driver.findElement(yearBuilt_xpath).clear();
		driver.findElement(yearBuilt_xpath).sendKeys(year);
	}
	
	public void selectNoOfUnits(String units) {
		Select sc = new Select(driver.findElement(selectNoOfUnits_id));
		sc.selectByVisibleText(units);
	}
	
	public void slectHomeDescribe(String type) {
		Select sc = new Select(driver.findElement(slectHomeDescribe_id));
		sc.selectByVisibleText(type);
	}
	
	public void minimun15k() {
		driver.findElement(minimun15k_xpath).click();
	}
	
	public void average25k() {
		driver.findElement(average25k_xpath).click();
	}
	
	public void thirteenK() {
		driver.findElement(thirteenK_xpath).click();
	}
	
	public void otherAmount() {
		driver.findElement(otherAmount_xpath).click();
	}
	
	public void yesDogs() {
		driver.findElement(yesDogs_xpath).click();
	}
	
	public void noDogs() {
		driver.findElement(noDogs_xpath).click();
	}
	
	public void selectExteriorWall(String type) {
		Select sc = new Select(driver.findElement(exteriorWall_id));
		sc.selectByVisibleText(type);
	}
	
	public void goToNxtPage() {
		driver.findElement(propertyInfoToNxtPage_id).click();
	}
	
	
	public void enterAllDetailsCorrect() throws IOException {
		getExcelData obb = new getExcelData();
		purchaseMonth(obb.getTheData("purchase date month", "propertyInfo"));
		purchaseYear(obb.getTheData("purchase date year", "propertyInfo"));
		fillYearBuild(obb.getTheData("year built", "propertyInfo"));
		selectNoOfUnits(obb.getTheData("units in building", "propertyInfo"));
		minimun15k();
		noDogs();	
		selectExteriorWall(obb.getTheData("exterior wall material", "propertyInfo"));
		goToNxtPage();
	}
	
	
}
