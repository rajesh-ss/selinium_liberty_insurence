package com.selenium.libertyA;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class currentInsurencePage {

	WebDriver driver;
	By mysuranceHasExcepired_xpath = By.xpath("//*[@id=\"currentlyInsured-currentInsurance-0\"]/div[2]/div/div[4]/label");
	By noOther_xpath = By.xpath("//*[@id=\"currentlyInsured-currentInsurance-0\"]/div[2]/div/div[5]/label");
	By haveOtherPolicies_xpath = By.xpath("//*[@id=\"hasOtherLibertyMutualPolicies-currentInsurance-0\"]/div[2]/div/div[1]/label");
	By noOtherPolicies_xpath = By.xpath("//*[@id=\"hasOtherLibertyMutualPolicies-currentInsurance-0\"]/div[2]/div/div[2]/label");
	By currentInsuranceToNxtPage_id = By.id("nextButton-1");
	
	
	public currentInsurencePage(WebDriver driver) {
		this.driver = driver;

	}
	
	public void selectAllDetailsCorrect() {
		clickInsuranceExpired();
		haveNoOtherPoilicies();
		goToNxtPage();
	}
	
	public void clickInsuranceExpired() {
		driver.findElement(mysuranceHasExcepired_xpath).click();
	}
	
	public void clickNoOther() {
		driver.findElement(noOther_xpath).click();
	}
	
	public void haveNoOtherPoilicies() {
		driver.findElement(haveOtherPolicies_xpath).click();
	}
	
	public void haveOtherPolicies() {
		driver.findElement(noOtherPolicies_xpath).click();
	}
	
	public void goToNxtPage() {
		driver.findElement(currentInsuranceToNxtPage_id).click();
	}
}
