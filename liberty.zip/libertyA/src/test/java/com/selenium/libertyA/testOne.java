package com.selenium.libertyA;

import java.io.IOException;
import org.testng.annotations.Test;

public class testOne extends testBase{
	
	@Test
	public void autoInsurance() throws Exception {
		
		
		landingPage obb = new landingPage(driver);
		obb.AutoCondo();
		
		
		/*
		 * 
		 */
		addressPage obb1 = new addressPage(driver);
		obb1.enterAllDetailsCorrect();
		
		/*
		 * 
		 */
		personalDataPage obb2 = new personalDataPage(driver);
		obb2.enterAllDetailsCorrect();
		
		/*
		 * 
		 */
		vehicleInfoPage obb3 = new vehicleInfoPage(driver);
		obb3.enterAllDetailsCorrect();

		/*
		 * 
		 */
		moreAboutVehiclePage obb4 = new moreAboutVehiclePage(driver);
		obb4.enterAllDetailsCorrect();
		/*
		 * 
		 */
		
		/*
		 * 
		 */
		addDriversPage obb5 = new addDriversPage(driver);
		obb5.enterAllDetailsCorrect();
		
		/*
		 * 
		 */
		
		fewMoreDriversDetails obb6 = new fewMoreDriversDetails(driver);
		obb6.enterAllDetailsCorrect();
		
		/*
		 * 
		 */
		funDiscountPage obb7  = new funDiscountPage(driver);
		obb7.goToNxtPage();
		
		/*
		 * 
		 */
		currentInsurencePage obb8 = new currentInsurencePage(driver);
		obb8.selectAllDetailsCorrect();
		/*
		 * 
		 */
		adressWantToInsurancePage obb9 = new adressWantToInsurancePage(driver);
		obb9.noAdressChangeNxtPage();
		/*
		 * 
		 */
		addSecondaryCondoPage obb10 = new addSecondaryCondoPage(driver);
		obb10.correctDetails();
		/*
		 * 
		 */
		currentInsuranceDetailsPage obb11 = new currentInsuranceDetailsPage(driver);
		obb11.fillCurrentDetails();
		
		/*
		 * 
		 */
		
		propertyInfoPage obb12 = new propertyInfoPage(driver);
		obb12.enterAllDetailsCorrect();
		
		/*
		 * 
		 */
		
		savingsAndMorePage obb13 = new savingsAndMorePage(driver);
		obb13.enterAllDetailsCorrect();
		
		
		quoteInfoPage obb14 = new quoteInfoPage(driver);
		obb14.closePopUp();
		takeScreenShotOnFail("test101", driver);
		
		
	}







}
